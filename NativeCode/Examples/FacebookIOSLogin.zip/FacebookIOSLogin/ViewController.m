//
//  ViewController.m
//  FacebookIOSLogin
//
//  Created by TranCong on 04/11/2021.
//

#import "ViewController.h"
#import <AdSupport/ASIdentifierManager.h>
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self
            selector:@selector(receiveNotification:)
            name:FBSDKAccessTokenDidChangeNotification
            object:nil];
    

NSUUID *adId = [[ASIdentifierManager sharedManager] advertisingIdentifier];
    NSString *str = [adId UUIDString];
    NSLog(@"AdID; %@",str);
}
-(IBAction)btnLogin:(id)sender{
    
    [FBSDKAppEvents logEvent:@"OPEN_FACEBOOK_LOGIN"];
    FBSDKLoginManager * loginManager = [[FBSDKLoginManager alloc] init];
    
    
    [loginManager logInWithPermissions:@[@"email",@"public_profile"] fromViewController:sender handler:^(FBSDKLoginManagerLoginResult * _Nullable result, NSError * _Nullable error) {
        if(result != NULL){
            NSLog(@"TOKEN: %@",result.token.tokenString);
            NSLog(@"USER_ID: %@",result.token.userID);
        }
    }];
    
    
}
-(IBAction)btnGraphAPI:(id)sender{
    
    NSDictionary *params = @{
        @"fields":@"id,name,email,picture.width(100).height(100)"
    };
    FBSDKGraphRequest *request = [[FBSDKGraphRequest alloc]
                                      initWithGraphPath:[NSString stringWithFormat:@"/me"]
                                      parameters:params
                                      HTTPMethod:@"GET"];
    [request startWithCompletion:^(id<FBSDKGraphRequestConnecting>  _Nullable connection, id  _Nullable result, NSError * _Nullable error) {
        if (!error){
           NSLog(@"result: %@",result);}
        else {
           NSLog(@"result: %@",[error description]);
         }
    }];
}

-(IBAction)btnAdTracking:(id)sender{
    /*FBSDKLoginManager * loginManager = [[FBSDKLoginManager alloc] init];
    [loginManager logOut];*/
    
    /*NSDictionary *params = @{@"_implicitlyLogged":@"1"};
    [FBSDKAppEvents logEvent:@"OPEN_IOS_FACEBOOK_REGISTER" parameters:params];*/
    
    
    [[AppsFlyerLib shared]  logEvent: AFEventAddToWishlist withValues: @{
        AFEventParamPrice: @20,
        AFEventParamContentId: @"123456"
    }];
}

- (void) receiveNotification:(NSNotification *) notification
{
    // [notification name] should always be @"TestNotification"
    // unless you use this method for observation of other notifications
    // as well.

    if ([[notification name] isEqualToString:FBSDKAccessTokenDidChangeNotification])
    {
        NSLog(@"FBSDKAccessTokenDidChangeNotification");
        if(notification.userInfo != NULL){
            BOOL hasChange = notification.userInfo[FBSDKAccessTokenDidChangeUserIDKey];
            if(hasChange){
                FBSDKAccessToken * accessToken =notification.userInfo[FBSDKAccessTokenChangeNewKey];
                NSLog(@"Refresh: %@",accessToken.userID);
                NSLog(@"Refresh: %@",accessToken.tokenString);
            }
        }
    }
}
@end
