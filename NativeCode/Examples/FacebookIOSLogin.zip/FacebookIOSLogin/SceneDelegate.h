//
//  SceneDelegate.h
//  FacebookIOSLogin
//
//  Created by TranCong on 04/11/2021.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit.h>
@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

