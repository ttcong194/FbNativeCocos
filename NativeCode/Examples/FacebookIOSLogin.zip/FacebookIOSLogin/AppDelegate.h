//
//  AppDelegate.h
//  FacebookIOSLogin
//
//  Created by TranCong on 04/11/2021.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit.h>
#import <AppsFlyerLib/AppsFlyerLib.h>
@interface AppDelegate : UIResponder <UIApplicationDelegate,AppsFlyerLibDelegate>

@property (strong, nonatomic) UIWindow *window;
@end

