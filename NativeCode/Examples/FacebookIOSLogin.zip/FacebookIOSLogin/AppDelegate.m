//
//  AppDelegate.m
//  FacebookIOSLogin
//
//  Created by TranCong on 04/11/2021.
//

#import "AppDelegate.h"
#import <AppTrackingTransparency/AppTrackingTransparency.h>
#import <AdSupport/AdSupport.h>
@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)requestIDFA {
    if (@available(iOS 14, *)) {
        [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status) {
          // Tracking authorization completed. Start loading ads here.
            if(status == ATTrackingManagerAuthorizationStatusAuthorized){
                [FBSDKSettings setAdvertiserTrackingEnabled:YES];
                //[FBSDKSettings setAdvertiserIDCollectionEnabled:YES];
                //[FBSDKSettings setAutoLogAppEventsEnabled:YES];
            }
            else{
                [FBSDKSettings setAdvertiserTrackingEnabled:NO];
            }
        }];
    }
}


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
   
    // Override point for customization after application launch.
    [[FBSDKApplicationDelegate sharedInstance] application:application didFinishLaunchingWithOptions:launchOptions];
    //[FBSDKSettings setAdvertiserTrackingEnabled:NO];
    
    [FBSDKSettings enableLoggingBehavior:FBSDKLoggingBehaviorAppEvents];
    [FBSDKSettings enableLoggingBehavior:FBSDKLoggingBehaviorNetworkRequests];
    [FBSDKSettings enableLoggingBehavior:FBSDKLoggingBehaviorDeveloperErrors];
    [FBSDKSettings enableLoggingBehavior:FBSDKLoggingBehaviorGraphAPIDebugInfo];
    [FBSDKSettings enableLoggingBehavior:FBSDKLoggingBehaviorAccessTokens];
    
    [FBSDKSettings setAutoLogAppEventsEnabled:YES];
    [FBSDKSettings setAdvertiserIDCollectionEnabled:YES];
    [FBSDKSettings setAdvertiserTrackingEnabled:YES];
    
    [[AppsFlyerLib shared] setAppsFlyerDevKey:@"RLNsarNxLQLVb9Er7GEg3o"];
    [[AppsFlyerLib shared] setAppleAppID:@"1590669056"];
    
    [AppsFlyerLib shared].isDebug = true;
    [[AppsFlyerLib shared] waitForATTUserAuthorizationWithTimeoutInterval:60];
        // Must be called AFTER setting appsFlyerDevKey and appleAppID
    [AppsFlyerLib shared].delegate = self;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
     selector:@selector(sendLaunch:)
     name:UIApplicationDidBecomeActiveNotification
     object:nil];
    
    [self requestIDFA];
    return YES;
}

- (void)sendLaunch:(UIApplication *)application {
    
    [[AppsFlyerLib shared] start];
}

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
            options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {

  BOOL handled = [[FBSDKApplicationDelegate sharedInstance] application:application
    openURL:url
    sourceApplication:options[UIApplicationOpenURLOptionsSourceApplicationKey]
    annotation:options[UIApplicationOpenURLOptionsAnnotationKey]
  ];
    return handled;
}
#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}

-(void)onConversionDataSuccess:(NSDictionary*) installData {
    // Business logic for Non-organic install scenario is invoked
    id status = [installData objectForKey:@"af_status"];
    if([status isEqualToString:@"Non-organic"]) {
        id sourceID = [installData objectForKey:@"media_source"];
        id campaign = [installData objectForKey:@"campaign"];
        NSLog(@"This is a Non-organic install. Media source: %@  Campaign: %@",sourceID,campaign);
    }

    else if([status isEqualToString:@"Organic"]) {
        // Business logic for Organic install scenario is invoked
        NSLog(@"This is an Organic install.");
    }

}
-(void)onConversionDataFail:(NSError *) error {
    NSLog(@"%@",error);
}

@end
