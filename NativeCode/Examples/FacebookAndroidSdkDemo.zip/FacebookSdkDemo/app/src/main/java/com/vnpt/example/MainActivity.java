package com.vnpt.example;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.appsflyer.AFInAppEventParameterName;
import com.appsflyer.AFInAppEventType;
import com.appsflyer.AppsFlyerLib;
import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.LoggingBehavior;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    CallbackManager callbackManager;
    AccessTokenTracker accessTokenTracker;
    ProfileTracker profileTracker;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        callbackManager = CallbackManager.Factory.create();

        accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(
                    AccessToken oldAccessToken,
                    AccessToken currentAccessToken) {
                // Set the access token using
                // currentAccessToken when it's loaded or set.
                if(oldAccessToken != null) {
                    Log.d("TAG", "old:" + oldAccessToken.getToken());
                }
                Log.d("TAG","new:"+currentAccessToken.getToken());

            }
        };

        profileTracker = new ProfileTracker() {
            @Override
            protected void onCurrentProfileChanged(
                    Profile oldProfile,
                    Profile currentProfile) {
                // App code
                if(oldProfile != null) {
                    Log.d("TAG", "old profile:" + oldProfile.getProfilePictureUri(100, 100).getPath());
                }
                Log.d("TAG","new profile:"+currentProfile.getProfilePictureUri(100,100).getPath());
            }
        };


        // Callback registration
        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // App code
                Log.d("TAG",loginResult.getAccessToken().getUserId());
            }

            @Override
            public void onCancel() {
                // App code
            }

            @Override
            public void onError(FacebookException exception) {
                // App code
            }
        });

        findViewById(R.id.btnLogin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppEventsLogger logger = AppEventsLogger.newLogger(MainActivity.this);
                logger.logEvent("OPEN_LOGIN_FACEBOOK",new Bundle());
                LoginManager.getInstance().logIn(MainActivity.this, Arrays.asList("public_profile","email"));
            }
        });
        findViewById(R.id.btnEvent).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Map<String, Object> eventValues = new HashMap<>();
                eventValues.put(AFInAppEventParameterName.PRICE, 1234.56);
                eventValues.put(AFInAppEventParameterName.CONTENT_ID,"1234567");

                AppsFlyerLib.getInstance().logEvent(MainActivity.this,
                        AFInAppEventType.ADD_TO_WISH_LIST , eventValues);

                AppsFlyerLib.getInstance().logEvent(MainActivity.this,
                        "af_open_login1" , eventValues);

                AppsFlyerLib.getInstance().logEvent(MainActivity.this,
                        "af_open_login2" , null);

                trackingEvent("af_open_login3",new Bundle());
            }
        });
        findViewById(R.id.btnGraph).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AccessToken accessToken = AccessToken.getCurrentAccessToken();
                if( accessToken != null && !accessToken.isExpired()){
                    /* make the API call */
                    Bundle params = new Bundle();
                    params.putString("fields", "id,name,email,picture.width(100).height(100)");

                    new GraphRequest(
                            AccessToken.getCurrentAccessToken(),
                            "/me",
                            params,
                            HttpMethod.GET,
                            new GraphRequest.Callback() {
                                public void onCompleted(GraphResponse response) {
                                    /* handle the result */
                                    Log.d("TAG",response.getRawResponse());
                                }

                            }
                    ).executeAsync();
                }
            }
        });
    }

    public void trackingEvent(String eventName,Bundle params){
                Map<String,Object> mapParams = this.bundleToMap(params);
                AppsFlyerLib.getInstance().logEvent(MainActivity.this,
                        eventName , mapParams);
    }

    public Map<String, Object> bundleToMap(Bundle extras) {
        Map<String, Object> map = new HashMap<String, Object>();

        Set<String> ks = extras.keySet();
        Iterator<String> iterator = ks.iterator();
        while (iterator.hasNext()) {
            String key = iterator.next();
            map.put(key, extras.get(key));
        }
        return map;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        accessTokenTracker.stopTracking();
        profileTracker.stopTracking();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
}